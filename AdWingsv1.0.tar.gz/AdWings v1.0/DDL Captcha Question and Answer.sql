-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 19, 2014 at 05:10 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `alphaamigo`
--

-- --------------------------------------------------------

--
-- Table structure for table `captcha`
--

CREATE TABLE IF NOT EXISTS `captcha` (
  `captcha_id` int(2) NOT NULL AUTO_INCREMENT,
  `captcha_question` varchar(50) DEFAULT NULL,
  `captcha_answer` int(2) DEFAULT NULL,
  PRIMARY KEY (`captcha_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `captcha`
--

INSERT INTO `captcha` (`captcha_id`, `captcha_question`, `captcha_answer`) VALUES
(1, 'What is 2+2?', 4),
(2, 'What is 1+1?', 2),
(3, 'What is 1+3?', 4),
(4, 'What is 1+4?', 5),
(5, 'What is 1+6?', 7),
(6, 'What is 1+5?', 6),
(7, 'What is 1+7?', 8),
(8, 'What is 1+9?', 10),
(9, 'What is 2+3?', 5),
(10, 'What is 2+1?', 3),
(11, 'What is 2+4?', 6),
(12, 'What is 2+5?', 7),
(13, 'What is 2+6?', 8),
(14, 'What is 2+7?', 9),
(15, 'What is 2+8?', 10),
(16, 'What is 3+1?', 4),
(17, 'What is 3+2?', 5),
(18, 'What is 1+1+1?', 3),
(19, 'What is 1+2+1?', 4),
(20, 'What is 1+2+2?', 5);
